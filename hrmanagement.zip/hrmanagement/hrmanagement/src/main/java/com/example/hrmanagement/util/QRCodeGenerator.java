package com.example.hrmanagement.util;

import com.google.zxing.*;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;

import java.nio.file.Path;

public class QRCodeGenerator {

    public static void generateQRCode(
            String text,
            String filePath)
            throws Exception {

        BitMatrix matrix =
                new MultiFormatWriter()
                        .encode(
                                text,
                                BarcodeFormat.QR_CODE,
                                300,
                                300
                        );

        MatrixToImageWriter.writeToPath(
                matrix,
                "PNG",
                Path.of(filePath)
        );
    }
}