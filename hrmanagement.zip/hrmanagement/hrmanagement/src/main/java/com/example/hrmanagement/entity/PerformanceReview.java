package com.example.hrmanagement.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name="performance_reviews")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PerformanceReview extends BaseEntity {

    @ManyToOne
    private Employee employee;

    private Integer technicalScore;

    private Integer communicationScore;

    private Integer teamworkScore;

    private Integer productivityScore;

    private Double finalRating;

    private String reviewer;

    private String remarks;
}