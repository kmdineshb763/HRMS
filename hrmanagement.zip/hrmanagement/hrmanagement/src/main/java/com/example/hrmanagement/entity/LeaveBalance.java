package com.example.hrmanagement.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "leave_balance")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LeaveBalance extends BaseEntity {

    @OneToOne
    @JoinColumn(name = "employee_id")
    private Employee employee;

    private Integer casualLeave = 12;

    private Integer sickLeave = 12;

    private Integer earnedLeave = 15;

    private Integer usedCasualLeave = 0;

    private Integer usedSickLeave = 0;

    private Integer usedEarnedLeave = 0;
}