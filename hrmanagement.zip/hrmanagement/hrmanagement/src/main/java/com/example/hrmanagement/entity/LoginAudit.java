package com.example.hrmanagement.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "login_audit")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoginAudit extends BaseEntity {

    private String username;

    private String ipAddress;

    private String browser;

    private LocalDateTime loginTime;

    private String loginStatus;

}