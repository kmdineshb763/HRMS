package com.example.hrmanagement.entity;


public enum LeaveType {

    CASUAL_LEAVE,
    SICK_LEAVE,
    EARNED_LEAVE,
    WORK_FROM_HOME,
    MATERNITY_LEAVE,
    PATERNITY_LEAVE

}