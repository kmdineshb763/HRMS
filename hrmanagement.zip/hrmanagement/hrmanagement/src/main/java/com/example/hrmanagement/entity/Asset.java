package com.example.hrmanagement.entity;

import java.time.LocalDate;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name="assets")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Asset extends BaseEntity {

    private String assetCode;

    private String assetName;

    private String assetType;

    private String serialNumber;

    private String manufacturer;

    private String modelNumber;

    private String assetStatus;
    
    @Entity
    @Table(name="employee_assets")
    public class EmployeeAsset extends BaseEntity {

        @ManyToOne
        private Employee employee;

        @ManyToOne
        private Asset asset;

        private LocalDate assignedDate;

        private LocalDate returnedDate;

        private boolean returned;
    }
    
}