package com.example.hrmanagement.service.impl;

import com.example.hrmanagement.entity.*;
import com.example.hrmanagement.repository.*;
import com.example.hrmanagement.service.AttendanceService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.*;

@Service
@RequiredArgsConstructor
public class AttendanceServiceImpl
        implements AttendanceService {

    private final AttendanceRepository attendanceRepository;
    private final EmployeeRepository employeeRepository;

    @Override
    public void checkIn(Long employeeId) {

        Employee employee =
                employeeRepository.findById(employeeId)
                        .orElseThrow();

        Attendance attendance =
                Attendance.builder()
                        .employee(employee)
                        .attendanceDate(LocalDate.now())
                        .checkInTime(LocalDateTime.now())
                        .status(AttendanceStatus.PRESENT)
                        .build();

        if(LocalTime.now().isAfter(
                LocalTime.of(9,30))) {

            attendance.setStatus(
                    AttendanceStatus.LATE
            );
        }

        attendanceRepository.save(attendance);
    }

    @Override
    public void checkOut(Long employeeId) {

        Employee employee =
                employeeRepository.findById(employeeId)
                        .orElseThrow();

        Attendance attendance =
                attendanceRepository
                        .findByEmployeeAndAttendanceDate(
                                employee,
                                LocalDate.now()
                        )
                        .orElseThrow();

        attendance.setCheckOutTime(
                LocalDateTime.now()
        );

        long minutes =
                Duration.between(
                        attendance.getCheckInTime(),
                        attendance.getCheckOutTime()
                ).toMinutes();

        attendance.setWorkingMinutes(
                (int) minutes
        );

        if(minutes > 540) {

            attendance.setOvertimeMinutes(
                    (int) (minutes - 540)
            );
        }

        attendanceRepository.save(attendance);
    }

    @Override
    public void breakIn(Long employeeId) {

        Employee employee =
                employeeRepository.findById(employeeId)
                        .orElseThrow();

        Attendance attendance =
                attendanceRepository
                        .findByEmployeeAndAttendanceDate(
                                employee,
                                LocalDate.now()
                        )
                        .orElseThrow();

        attendance.setBreakInTime(
                LocalDateTime.now()
        );

        attendanceRepository.save(attendance);
    }

    @Override
    public void breakOut(Long employeeId) {

        Employee employee =
                employeeRepository.findById(employeeId)
                        .orElseThrow();

        Attendance attendance =
                attendanceRepository
                        .findByEmployeeAndAttendanceDate(
                                employee,
                                LocalDate.now()
                        )
                        .orElseThrow();

        attendance.setBreakOutTime(
                LocalDateTime.now()
        );

        attendanceRepository.save(attendance);
    }
}