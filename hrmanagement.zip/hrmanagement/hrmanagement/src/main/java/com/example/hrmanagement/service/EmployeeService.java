package com.example.hrmanagement.service;

import com.example.hrmanagement.entity.Employee;

import java.util.List;

public interface EmployeeService {

    Employee save(Employee employee);

    Employee update(Long id, Employee employee);

    Employee findById(Long id);

    List<Employee> findAll();
   
    private final UserRepository userRepository;

    private final PasswordEncoder passwordEncoder;

    private final EmailService emailService;
    void delete(Long id);

}