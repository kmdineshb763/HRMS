package com.example.hrmanagement.repository;

import com.example.hrmanagement.entity.EmployeeBankDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeBankRepository
        extends JpaRepository<EmployeeBankDetails, Long> {
}