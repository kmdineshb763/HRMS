package com.example.hrmanagement.service;

import com.example.hrmanagement.dto.DashboardStatsDto;

public interface DashboardService {

    DashboardStatsDto getAdminDashboard();

}