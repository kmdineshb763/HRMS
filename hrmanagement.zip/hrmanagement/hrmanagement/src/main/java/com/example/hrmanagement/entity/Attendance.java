package com.example.hrmanagement.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "attendance")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Attendance extends BaseEntity {

    @ManyToOne
    @JoinColumn(name = "employee_id")
    private Employee employee;

    private LocalDate attendanceDate;

    private LocalDateTime checkInTime;

    private LocalDateTime checkOutTime;

    private LocalDateTime breakInTime;

    private LocalDateTime breakOutTime;

    private Double latitude;

    private Double longitude;

    private Integer workingMinutes;

    private Integer overtimeMinutes;

    @Enumerated(EnumType.STRING)
    private AttendanceStatus status;
}