package com.example.hrmanagement.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "permission_requests")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PermissionRequest extends BaseEntity {

    @ManyToOne
    @JoinColumn(name = "employee_id")
    private Employee employee;

    private LocalDate requestDate;

    private LocalTime fromTime;

    private LocalTime toTime;

    private Integer totalMinutes;

    private String reason;

    @Enumerated(EnumType.STRING)
    private LeaveStatus status;
}