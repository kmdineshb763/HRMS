package com.example.hrmanagement.entity;


import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "candidates")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Candidate extends BaseEntity {

    private String fullName;

    private String email;

    private String mobile;

    private String positionApplied;

    private Double expectedSalary;

    private Integer experienceYears;

    private String resumePath;

    @Enumerated(EnumType.STRING)
    
    private CandidateStatus status;
}