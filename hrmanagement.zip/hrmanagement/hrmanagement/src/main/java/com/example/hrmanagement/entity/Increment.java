package com.example.hrmanagement.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name="increments")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Increment extends BaseEntity {

    @ManyToOne
    private Employee employee;

    private Double previousSalary;

    private Double incrementAmount;

    private Double revisedSalary;

    private String approvedBy;

    private String reason;
}