package com.example.hrmanagement.controller.employee;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.hrmanagement.dto.EmployeeDashboardDto;

@Controller
public class EmployeeDashboardController {

    @GetMapping("/employee/dashboard")
    public String dashboard() {

        return "employee/dashboard";
    }
    @GetMapping("/employee/dashboard")
    public String dashboard(
            Model model){

    EmployeeDashboardDto dto =
    new EmployeeDashboardDto();

    dto.setEmployeeCode(
    "TSC-JD-00001"
    );

    dto.setPresentDays(22);

    dto.setLeaveDays(2);

    dto.setSalary(65000);

    model.addAttribute(
    "dashboard",
    dto
    );

    return "employee/dashboard";
    }
}