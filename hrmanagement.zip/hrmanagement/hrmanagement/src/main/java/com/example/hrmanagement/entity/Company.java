package com.example.hrmanagement.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name="company")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Company extends BaseEntity {

    private String companyName;

    private String companyCode;

    private String email;

    private String mobile;

    private String website;

    private String gstNumber;

    private String panNumber;

    private String logoPath;
}