package com.example.hrmanagement.controller.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.hrmanagement.service.DashboardService;

@Controller
public class AdminDashboardController {

    @GetMapping("/admin/dashboard")
    public String dashboard() {

        return "admin/dashboard";
    }
    @Autowired
    private final DashboardService dashboardService;

    @GetMapping("/admin/dashboard")
    public String dashboard(
            Model model){

        model.addAttribute(
                "stats",
                dashboardService
                        .getAdminDashboard()
        );

        return "admin/dashboard";
    }
}
