package com.example.hrmanagement.service.impl;

import com.example.hrmanagement.entity.Employee;
import com.example.hrmanagement.repository.EmployeeRepository;
import com.example.hrmanagement.service.EmployeeService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EmployeeServiceImpl
        implements EmployeeService {

    private final EmployeeRepository employeeRepository;

    @Override
    public Employee save(Employee employee) {

        employee.setEmployeeCode(generateCode());

        return employeeRepository.save(employee);
    }

    @Override
    public Employee update(Long id,
                           Employee employee) {

        Employee existing =
                employeeRepository.findById(id)
                        .orElseThrow();

        existing.setFirstName(employee.getFirstName());
        existing.setLastName(employee.getLastName());
        existing.setEmail(employee.getEmail());
        existing.setMobile(employee.getMobile());
        existing.setDesignation(employee.getDesignation());
        existing.setStatus(employee.getStatus());

        return employeeRepository.save(existing);
    }

    @Override
    public Employee findById(Long id) {
        return employeeRepository.findById(id)
                .orElseThrow();
    }

    @Override
    public List<Employee> findAll() {
        return employeeRepository.findAll();
    }

    @Override
    public void delete(Long id) {
        employeeRepository.deleteById(id);
    }

    private String generateCode() {

        long count =
                employeeRepository.count() + 1;

        return String.format(
                "TSC-EMP-%05d",
                count
        );
    }
}