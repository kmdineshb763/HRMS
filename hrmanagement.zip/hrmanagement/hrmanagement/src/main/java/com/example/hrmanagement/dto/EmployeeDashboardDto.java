package com.example.hrmanagement.dto;

import lombok.Data;

@Data
public class EmployeeDashboardDto {

    private String employeeCode;

    private int presentDays;

    private int leaveDays;

    private double salary;

    private int notifications;
}