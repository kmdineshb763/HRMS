package com.example.hrmanagement.service.impl;

import com.example.hrmanagement.dto.DashboardStatsDto;
import com.example.hrmanagement.repository.*;
import com.example.hrmanagement.service.DashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DashboardServiceImpl
        implements DashboardService {

    private final EmployeeRepository employeeRepository;

    @Override
    public DashboardStatsDto getAdminDashboard() {

        DashboardStatsDto dto =
                new DashboardStatsDto();

        dto.setTotalEmployees(
                employeeRepository.count()
        );

        return dto;
    }
}