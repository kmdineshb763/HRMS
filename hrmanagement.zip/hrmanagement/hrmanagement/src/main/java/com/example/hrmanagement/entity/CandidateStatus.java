package com.example.hrmanagement.entity;

public enum CandidateStatus {

    APPLIED,
    SHORTLISTED,
    INTERVIEW_SCHEDULED,
    INTERVIEWED,
    OFFER_RELEASED,
    HIRED,
    REJECTED

}