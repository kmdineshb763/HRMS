package com.example.hrmanagement.service;



public interface PayslipPdfService {

    byte[] generatePayslip(
            Long payrollId)
            throws Exception;

}