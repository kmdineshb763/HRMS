package com.example.hrmanagement.service;

import com.example.hrmanagement.entity.LeaveRequest;

import java.util.List;

public interface LeaveService {

    LeaveRequest applyLeave(
            LeaveRequest request);

    LeaveRequest approveByTL(
            Long leaveId);

    LeaveRequest approveByHR(
            Long leaveId);

    LeaveRequest reject(
            Long leaveId);

    List<LeaveRequest> findAll();

}