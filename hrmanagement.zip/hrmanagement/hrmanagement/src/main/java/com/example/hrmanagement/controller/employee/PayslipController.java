package com.example.hrmanagement.controller.employee;

import com.example.hrmanagement.service.PayslipPdfService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/employee/payslip")
public class PayslipController {

    private final PayslipPdfService pdfService;

    @GetMapping("/download/{id}")
    public ResponseEntity<byte[]>
    downloadPayslip(
            @PathVariable Long id)
            throws Exception {

        byte[] pdf =
                pdfService.generatePayslip(
                        id
                );

        return ResponseEntity.ok()
                .header(
                        HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=payslip.pdf"
                )
                .contentType(
                        MediaType.APPLICATION_PDF
                )
                .body(pdf);
    }
}