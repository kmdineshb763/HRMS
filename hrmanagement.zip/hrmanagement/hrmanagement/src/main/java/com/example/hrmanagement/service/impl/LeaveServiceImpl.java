package com.example.hrmanagement.service.impl;

import com.example.hrmanagement.entity.*;
import com.example.hrmanagement.repository.*;
import com.example.hrmanagement.service.LeaveService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class LeaveServiceImpl
        implements LeaveService {

    private final LeaveRepository leaveRepository;

    @Override
    public LeaveRequest applyLeave(
            LeaveRequest request) {

        request.setStatus(
                LeaveStatus.PENDING
        );

        return leaveRepository.save(
                request
        );
    }

    @Override
    public LeaveRequest approveByTL(
            Long leaveId) {

        LeaveRequest leave =
                leaveRepository.findById(
                        leaveId
                ).orElseThrow();

        leave.setStatus(
                LeaveStatus.TL_APPROVED
        );

        leave.setApprovedBy(
                "TEAM_LEAD"
        );

        return leaveRepository.save(
                leave
        );
    }

    @Override
    public LeaveRequest approveByHR(
            Long leaveId) {

        LeaveRequest leave =
                leaveRepository.findById(
                        leaveId
                ).orElseThrow();

        leave.setStatus(
                LeaveStatus.HR_APPROVED
        );

        leave.setApprovedBy(
                "HR"
        );

        return leaveRepository.save(
                leave
        );
    }

    @Override
    public LeaveRequest reject(
            Long leaveId) {

        LeaveRequest leave =
                leaveRepository.findById(
                        leaveId
                ).orElseThrow();

        leave.setStatus(
                LeaveStatus.REJECTED
        );

        return leaveRepository.save(
                leave
        );
    }

    @Override
    public java.util.List<LeaveRequest>
    findAll() {

        return leaveRepository.findAll();
    }
}