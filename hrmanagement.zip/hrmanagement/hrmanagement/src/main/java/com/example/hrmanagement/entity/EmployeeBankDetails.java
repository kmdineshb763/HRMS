package com.example.hrmanagement.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "employee_bank_details")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmployeeBankDetails extends BaseEntity {

    @OneToOne
    @JoinColumn(name = "employee_id")
    private Employee employee;

    private String bankName;

    private String accountHolderName;

    private String accountNumber;

    private String ifscCode;

    private String branchName;

    private String upiId;

    private boolean verified;
}