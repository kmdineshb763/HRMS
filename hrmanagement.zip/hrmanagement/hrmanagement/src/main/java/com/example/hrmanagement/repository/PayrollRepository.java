package com.example.hrmanagement.repository;

import com.example.hrmanagement.entity.Payroll;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PayrollRepository
        extends JpaRepository<Payroll, Long> {
}