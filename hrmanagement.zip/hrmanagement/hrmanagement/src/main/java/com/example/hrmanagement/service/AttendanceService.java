package com.example.hrmanagement.service;

public interface AttendanceService {

    void checkIn(Long employeeId);

    void checkOut(Long employeeId);

    void breakIn(Long employeeId);

    void breakOut(Long employeeId);

}