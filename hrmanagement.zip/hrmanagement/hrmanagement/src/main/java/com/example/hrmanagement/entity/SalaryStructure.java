package com.example.hrmanagement.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "salary_structure")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SalaryStructure extends BaseEntity {

    @OneToOne
    @JoinColumn(name = "employee_id")
    private Employee employee;

    private Double basicSalary;

    private Double hra;

    private Double specialAllowance;

    private Double medicalAllowance;

    private Double conveyanceAllowance;

    private Double bonus;

    private Double pf;

    private Double esi;

    private Double professionalTax;

    private Double incomeTax;

}