package com.example.hrmanagement.controller.employee;

import com.example.hrmanagement.entity.LeaveRequest;
import com.example.hrmanagement.service.LeaveService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
@RequestMapping("/employee/leave")
public class LeaveController {

    private final LeaveService leaveService;

    @PostMapping("/apply")
    public String applyLeave(
            @ModelAttribute LeaveRequest leave) {

        leaveService.applyLeave(
                leave
        );

        return "redirect:/employee/dashboard";
    }
}