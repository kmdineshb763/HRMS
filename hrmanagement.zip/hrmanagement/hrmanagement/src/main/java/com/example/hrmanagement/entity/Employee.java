package com.example.hrmanagement.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "employees")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Employee extends BaseEntity {

    @Column(unique = true)
    private String employeeCode;

    private String firstName;

    private String lastName;

    private String email;

    private String mobile;

    private String gender;

    private LocalDate dateOfBirth;

    private LocalDate joiningDate;

    private String designation;

    private String profilePhoto;
    
    private Double latitude;

    private Double longitude;

    @Enumerated(EnumType.STRING)
    private EmployeeStatus status;

    @ManyToOne
    @JoinColumn(name = "department_id")
    private Department department;

}