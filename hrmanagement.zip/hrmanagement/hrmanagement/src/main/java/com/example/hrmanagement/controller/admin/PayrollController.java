package com.example.hrmanagement.controller.admin;

import com.example.hrmanagement.service.PayrollService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
@RequestMapping("/admin/payroll")
public class PayrollController {

    private final PayrollService payrollService;

    @PostMapping("/generate")
    public String generate(
            Long employeeId,
            Integer month,
            Integer year) {

        payrollService.generatePayroll(
                employeeId,
                month,
                year
        );

        return "redirect:/admin/payroll";
    }
}