package com.example.hrmanagement.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name="employee_exit")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmployeeExit extends BaseEntity {

    @ManyToOne
    private Employee employee;

    private LocalDate resignationDate;

    private LocalDate lastWorkingDay;

    private String exitReason;

    private String exitStatus;

    private boolean assetReturned;

    private boolean clearanceCompleted;
}