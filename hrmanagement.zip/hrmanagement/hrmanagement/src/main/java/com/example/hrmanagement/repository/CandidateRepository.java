package com.example.hrmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.hrmanagement.entity.*;
public interface CandidateRepository
extends JpaRepository<Candidate,Long>{
}