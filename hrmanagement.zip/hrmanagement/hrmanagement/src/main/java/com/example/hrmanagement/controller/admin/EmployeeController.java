package com.example.hrmanagement.controller.admin;

import com.example.hrmanagement.entity.Employee;
import com.example.hrmanagement.entity.EmployeeStatus;
import com.example.hrmanagement.service.EmployeeService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
@RequestMapping("/admin/employees")
public class EmployeeController {

    private final EmployeeService employeeService;

    @GetMapping
    public String list(Model model) {

        model.addAttribute(
                "employees",
                employeeService.findAll()
        );

        return "admin/employee-list";
    }

    @GetMapping("/add")
    public String addForm(Model model) {

        model.addAttribute(
                "employee",
                new Employee()
        );

        model.addAttribute(
                "statuses",
                EmployeeStatus.values()
        );

        return "admin/employee-add";
    }

    @PostMapping("/save")
    public String save(
            @ModelAttribute Employee employee) {

        employeeService.save(employee);

        return "redirect:/admin/employees";
    }

}
