package com.example.hrmanagement.service;

import com.example.hrmanagement.entity.Payroll;

public interface PayrollService {

    Payroll generatePayroll(
            Long employeeId,
            Integer month,
            Integer year);

}