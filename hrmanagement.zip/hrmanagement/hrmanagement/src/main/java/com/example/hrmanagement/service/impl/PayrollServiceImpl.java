package com.example.hrmanagement.service.impl;

import com.example.hrmanagement.entity.*;
import com.example.hrmanagement.repository.*;
import com.example.hrmanagement.service.PayrollService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PayrollServiceImpl
        implements PayrollService {

    private final EmployeeRepository employeeRepository;
    private final SalaryStructureRepository salaryRepository;
    private final PayrollRepository payrollRepository;

    @Override
    public Payroll generatePayroll(
            Long employeeId,
            Integer month,
            Integer year) {

        Employee employee =
                employeeRepository.findById(employeeId)
                        .orElseThrow();

        SalaryStructure salary =
                salaryRepository.findByEmployee(employee)
                        .orElseThrow();

        double grossSalary =
                salary.getBasicSalary()
                + salary.getHra()
                + salary.getMedicalAllowance()
                + salary.getConveyanceAllowance()
                + salary.getSpecialAllowance()
                + salary.getBonus();

        double deduction =
                salary.getPf()
                + salary.getEsi()
                + salary.getProfessionalTax()
                + salary.getIncomeTax();

        double netSalary =
                grossSalary - deduction;

        Payroll payroll =
                Payroll.builder()
                        .employee(employee)
                        .payrollMonth(month)
                        .payrollYear(year)
                        .grossSalary(grossSalary)
                        .totalDeduction(deduction)
                        .netSalary(netSalary)
                        .payrollStatus("GENERATED")
                        .generatedBy("ADMIN")
                        .build();

        return payrollRepository.save(payroll);
    }
}