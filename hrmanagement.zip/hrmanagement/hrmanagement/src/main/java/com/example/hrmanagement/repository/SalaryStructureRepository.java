package com.example.hrmanagement.repository;

import com.example.hrmanagement.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface SalaryStructureRepository
        extends JpaRepository<SalaryStructure, Long> {

    Optional<SalaryStructure>
    findByEmployee(Employee employee);
}