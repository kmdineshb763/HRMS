package com.example.hrmanagement.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "salary_history")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SalaryHistory extends BaseEntity {

    private String employeeCode;

    private Double oldSalary;

    private Double newSalary;

    private String changedBy;

    private String remarks;
}