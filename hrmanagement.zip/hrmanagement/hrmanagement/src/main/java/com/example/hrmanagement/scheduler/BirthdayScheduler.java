package com.example.hrmanagement.scheduler;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class BirthdayScheduler {

    @Scheduled(cron = "0 0 8 * * ?")
    public void birthdayAlert() {

        System.out.println(
                "Birthday Notifications"
        );
    }
    @Scheduled(cron="0 0 8 * * ?")
    public void anniversaryAlert(){

    System.out.println(
    "Work Anniversary Alert"
    );

    }
}