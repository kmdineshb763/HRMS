package com.example.hrmanagement.controller.auth;

import com.example.hrmanagement.service.OtpService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
public class ForgotPasswordController {

    private final OtpService otpService;

    @GetMapping("/forgot-password")
    public String forgotPassword() {

        return "auth/forgot-password";
    }

    @PostMapping("/forgot-password")
    public String sendOtp(
            String email) {

        otpService.sendOtp(
                email
        );

        return "redirect:/verify-otp";
    }
}