package com.example.hrmanagement.entity;

import java.time.LocalDate;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "payroll")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Payroll extends BaseEntity {

    @ManyToOne
    @JoinColumn(name = "employee_id")
    private Employee employee;

    private Integer payrollMonth;

    private Integer payrollYear;

    private Double grossSalary;

    private Double totalDeduction;

    private Double overtimeAmount;

    private Double netSalary;

    private Integer workingDays;

    private Integer presentDays;

    private Integer leaveDays;

    private String payrollStatus;

    private String generatedBy;
    
    @Enumerated(EnumType.STRING)
    private SalaryPaymentStatus paymentStatus;

    private LocalDate salaryCreditDate;

    private String transactionReference;

}