package com.example.hrmanagement.entity;

public enum LeaveStatus {

    PENDING,
    TL_APPROVED,
    HR_APPROVED,
    REJECTED,
    CANCELLED

}