package com.example.hrmanagement.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name="promotions")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Promotion extends BaseEntity {

    @ManyToOne
    private Employee employee;

    private String oldDesignation;

    private String newDesignation;

    private Double oldSalary;

    private Double newSalary;

    private String approvedBy;

    private String remarks;
}