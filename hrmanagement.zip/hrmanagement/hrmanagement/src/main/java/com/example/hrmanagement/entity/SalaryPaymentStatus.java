package com.example.hrmanagement.entity;

public enum SalaryPaymentStatus {

    PENDING,
    PROCESSING,
    SUCCESS,
    FAILED

}