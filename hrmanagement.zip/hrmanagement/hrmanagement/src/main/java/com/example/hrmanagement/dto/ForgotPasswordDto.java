package com.example.hrmanagement.dto;

import lombok.Data;

@Data
public class ForgotPasswordDto {

    private String email;
}
