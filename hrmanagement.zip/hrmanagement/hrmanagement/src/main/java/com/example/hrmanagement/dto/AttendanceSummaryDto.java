package com.example.hrmanagement.dto;

import lombok.Data;

@Data
public class AttendanceSummaryDto {

    private int presentDays;

    private int absentDays;

    private int lateDays;

    private int leaveDays;

    private int overtimeHours;
}