package com.example.hrmanagement.repository;

import com.example.hrmanagement.entity.PermissionRequest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PermissionRepository
        extends JpaRepository<PermissionRequest, Long> {
}