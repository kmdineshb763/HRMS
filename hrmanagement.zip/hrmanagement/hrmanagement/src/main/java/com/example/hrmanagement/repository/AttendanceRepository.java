package com.example.hrmanagement.repository;


import com.example.hrmanagement.entity.Attendance;
import com.example.hrmanagement.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.Optional;
import java.util.List;

public interface AttendanceRepository
        extends JpaRepository<Attendance, Long> {

    Optional<Attendance> findByEmployeeAndAttendanceDate(
            Employee employee,
            LocalDate date
    );

    List<Attendance> findByEmployee(Employee employee);
}