package com.example.hrmanagement.entity;


import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "otp_verification")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OtpVerification extends BaseEntity {

    private String email;

    private String mobile;

    private String otp;

    private LocalDateTime expiryTime;

    private boolean verified;

}