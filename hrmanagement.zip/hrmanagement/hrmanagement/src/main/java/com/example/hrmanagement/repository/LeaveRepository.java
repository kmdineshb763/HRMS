package com.example.hrmanagement.repository;


import com.example.hrmanagement.entity.LeaveRequest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LeaveRepository
        extends JpaRepository<LeaveRequest, Long> {
}
