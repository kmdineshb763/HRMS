package com.example.hrmanagement.entity;



import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name="branches")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Branch extends BaseEntity {

    private String branchCode;

    private String branchName;

    private String city;

    private String state;

    private String country;
}