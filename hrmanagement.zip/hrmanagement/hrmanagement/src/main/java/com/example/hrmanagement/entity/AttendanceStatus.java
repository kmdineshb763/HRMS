package com.example.hrmanagement.entity;

public enum AttendanceStatus {

    PRESENT,
    ABSENT,
    HALF_DAY,
    LATE,
    WORK_FROM_HOME,
    ON_LEAVE,
    ON_DUTY

}