package com.example.hrmanagement.service.impl;


import com.example.hrmanagement.service.EmailService;
import lombok.RequiredArgsConstructor;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class EmailServiceImpl
        implements EmailService {

    private final JavaMailSender mailSender;

    @Override
    public void sendEmployeeCredentials(
            String email,
            String employeeCode,
            String username,
            String password
    ) {

        SimpleMailMessage message =
                new SimpleMailMessage();

        message.setTo(email);

        message.setSubject(
                "Welcome To TSC Payroll System"
        );

        message.setText(
                "Employee Code : " + employeeCode
                        + "\nUsername : " + username
                        + "\nPassword : " + password
                        + "\nLogin URL : http://localhost:8080/login"
        );

        mailSender.send(message);
    }
}
