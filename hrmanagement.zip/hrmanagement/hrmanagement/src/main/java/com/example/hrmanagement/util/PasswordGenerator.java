package com.example.hrmanagement.util;

import java.security.SecureRandom;

public class PasswordGenerator {

    private static final String CHARACTERS =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                    + "abcdefghijklmnopqrstuvwxyz"
                    + "0123456789@#$";

    public static String generatePassword() {

        SecureRandom random =
                new SecureRandom();

        StringBuilder password =
                new StringBuilder();

        for (int i = 0; i < 10; i++) {

            password.append(
                    CHARACTERS.charAt(
                            random.nextInt(
                                    CHARACTERS.length()
                            )
                    )
            );
        }

        return password.toString();
    }
}