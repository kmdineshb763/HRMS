package com.example.hrmanagement.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DashboardStatsDto {

    private long totalEmployees;

    private long activeEmployees;

    private long inactiveEmployees;

    private long presentEmployees;

    private long absentEmployees;

    private long pendingLeaves;

    private double monthlyPayroll;

    private double yearlyPayroll;
}