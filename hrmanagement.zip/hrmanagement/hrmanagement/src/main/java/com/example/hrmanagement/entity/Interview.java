package com.example.hrmanagement.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name="interviews")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Interview extends BaseEntity {

    @ManyToOne
    private Candidate candidate;

    private String interviewer;

    private LocalDateTime interviewDateTime;

    private String meetingLink;

    private String remarks;

    private String result;
}