package com.example.hrmanagement.controller.employee;

import com.example.hrmanagement.service.AttendanceService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
@RequestMapping("/employee/attendance")
public class AttendanceController {

    private final AttendanceService attendanceService;

    @PostMapping("/checkin/{id}")
    public String checkIn(
            @PathVariable Long id) {

        attendanceService.checkIn(id);

        return "redirect:/employee/dashboard";
    }

    @PostMapping("/checkout/{id}")
    public String checkOut(
            @PathVariable Long id) {

        attendanceService.checkOut(id);

        return "redirect:/employee/dashboard";
    }

    @PostMapping("/breakin/{id}")
    public String breakIn(
            @PathVariable Long id) {

        attendanceService.breakIn(id);

        return "redirect:/employee/dashboard";
    }

    @PostMapping("/breakout/{id}")
    public String breakOut(
            @PathVariable Long id) {

        attendanceService.breakOut(id);

        return "redirect:/employee/dashboard";
    }
}