package com.example.hrmanagement.service.impl;

import com.example.hrmanagement.entity.OtpVerification;
import com.example.hrmanagement.repository.OtpRepository;
import com.example.hrmanagement.service.EmailService;
import com.example.hrmanagement.service.OtpService;
import com.example.hrmanagement.util.OtpGenerator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class OtpServiceImpl
        implements OtpService {

    private final OtpRepository otpRepository;

    private final EmailService emailService;

    @Override
    public void sendOtp(String email) {

        String otp =
                OtpGenerator.generateOtp();

        OtpVerification verification =
                OtpVerification.builder()
                        .email(email)
                        .otp(otp)
                        .expiryTime(
                                LocalDateTime.now()
                                        .plusMinutes(5)
                        )
                        .verified(false)
                        .build();

        otpRepository.save(
                verification
        );

        emailService.sendOtpMail(
                email,
                otp
        );
    }

    @Override
    public boolean verifyOtp(
            String email,
            String otp) {

        OtpVerification record =
                otpRepository
                        .findTopByEmailOrderByIdDesc(
                                email
                        )
                        .orElseThrow();

        if(record.getOtp().equals(otp)
                && LocalDateTime.now()
                .isBefore(
                        record.getExpiryTime()
                )) {

            record.setVerified(true);

            otpRepository.save(record);

            return true;
        }

        return false;
    }
}