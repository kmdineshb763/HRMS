package com.example.hrmanagement.service;

public interface EmailService {

    void sendEmployeeCredentials(
            String email,
            String employeeCode,
            String username,
            String password
    );
}
