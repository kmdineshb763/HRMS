package com.example.hrmanagement.service.impl;

import com.example.hrmanagement.service.PayslipPdfService;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;

@Service
public class PayslipPdfServiceImpl
        implements PayslipPdfService {

    @Override
    public byte[] generatePayslip(
            Long payrollId)
            throws Exception {

        ByteArrayOutputStream output =
                new ByteArrayOutputStream();

        Document document =
                new Document();

        PdfWriter.getInstance(
                document,
                output
        );

        document.open();

        document.add(
                new Paragraph(
                        "TSC TECHNOLOGIES"
                )
        );

        document.add(
                new Paragraph(
                        "Salary Payslip"
                )
        );

        document.add(
                new Paragraph(
                        "Payroll ID : "
                                + payrollId
                )
        );

        document.close();

        return output.toByteArray();
    }
}